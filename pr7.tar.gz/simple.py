from llvmlite import ir
import llvmlite.binding as llvm
import ctypes

llvm.initialize()
llvm.initialize_native_target()
llvm.initialize_native_asmprinter()

def create_execution_engine():
    target = llvm.Target.from_default_triple()
    target_machine = target.create_target_machine()
    backing_module = llvm.parse_assembly("")
    engine = llvm.create_mcjit_compiler(backing_module, target_machine)
    return engine

def create_module():
    i64_type = ir.IntType(bits=64)
    fn_type = ir.FunctionType(args=(i64_type, i64_type), return_type=i64_type)

    module = ir.Module(name="test")

    func = ir.Function(module, fn_type, name="myfunc")
    block = func.append_basic_block(name="entry")
    builder = ir.IRBuilder(block)
    a, b = func.args
    result = builder.add(a, b, name="res")
    builder.ret(result)
    
    return module

module = create_module()
print("---- Compiled module ----")
print(module)
print("---- Compiled module ----")

with create_execution_engine() as ee:
    ee.add_module(llvm.parse_assembly(str(module)))
    ee.finalize_object()
    ee.run_static_constructors()

    # compiles intermediate repr
    # writes binary code to memory

    func_ptr = ee.get_function_address("myfunc")
    cfunc = ctypes.CFUNCTYPE(ctypes.c_int64, ctypes.c_int64, ctypes.c_int64)(func_ptr)
    print("myfunc(1, 4) =", cfunc(1, 4))
