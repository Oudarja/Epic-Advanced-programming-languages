from llvmlite import ir
import llvmlite.binding as llvm
import ctypes

llvm.initialize()
llvm.initialize_native_target()
llvm.initialize_native_asmprinter()

def print_wrapper(x):
    print("Got value", x)

printfn_type = ctypes.CFUNCTYPE(None, ctypes.c_int64)
printfn = printfn_type(print_wrapper)

llvm.add_symbol(
    "print",
    ctypes.cast(printfn, ctypes.c_void_p).value)

def create_execution_engine():
    target = llvm.Target.from_default_triple()
    target_machine = target.create_target_machine()
    backing_module = llvm.parse_assembly("")
    engine = llvm.create_mcjit_compiler(backing_module, target_machine)
    return engine

def create_module():
    i64_type = ir.IntType(bits=64)
    fn_type = ir.FunctionType(args=(i64_type,), return_type=ir.VoidType())

    module = ir.Module(name="test")
    print_func = ir.Function(module, ir.FunctionType(args=(i64_type,), return_type=ir.VoidType()), name="print")

    func = ir.Function(module, fn_type, name="myfunc")
    num = func.args[0]

    entry = func.append_basic_block(name="entry")
    loop = func.append_basic_block(name="loop")
    fin = func.append_basic_block(name="fin")

    a0 = ir.Constant(i64_type, 0)
    b0 = ir.Constant(i64_type, 1)

    entry_builder = ir.IRBuilder(entry)
    cond = entry_builder.icmp_signed('==', num, ir.Constant(i64_type, 0), "c0")
    entry_builder.cbranch(cond, fin, loop)
    
    loop_builder = ir.IRBuilder(loop)
    i = loop_builder.phi(i64_type, name="i")
    i.add_incoming(num, entry)

    a = loop_builder.phi(i64_type, name="a")
    b = loop_builder.phi(i64_type, name="b")
    a.add_incoming(a0, entry)
    a.add_incoming(b, loop)
    #c = loop_builder.add(a, b, name="c")
    c = loop_builder.add(
            loop_builder.add(
                loop_builder.add(a, b, name="c"),
                ir.Constant(i64_type, 1)),
            ir.Constant(i64_type, -1))
    b.add_incoming(b0, entry)
    b.add_incoming(c, loop)

    i1 = loop_builder.sub(i, ir.Constant(i64_type, 1), name="i1")
    i.add_incoming(i1, loop)

    cond = loop_builder.icmp_signed('==', i1, ir.Constant(i64_type, 0), "cond")
    loop_builder.cbranch(cond, fin, loop)
    
    fin_builder = ir.IRBuilder(fin)
    b1 = fin_builder.phi(i64_type, name="b1")
    b1.add_incoming(b0, entry)
    b1.add_incoming(c, loop)
    fin_builder.call(print_func, [b1,])
    fin_builder.ret_void()

    return module

module = create_module()
print("---- Compiled module ----")
print(module)
print("---- Compiled module ----")

with create_execution_engine() as ee:
    mod = llvm.parse_assembly(str(module))
    mod.verify()

    open('orig.bc', 'wb').write(mod.as_bitcode())

    pass_manager = llvm.PassManagerBuilder()
    pass_manager.opt_level = 3
    module_pass = llvm.ModulePassManager()
    pass_manager.populate(module_pass)
    module_pass.run(mod)

    open('opt.bc', 'wb').write(mod.as_bitcode())

    ee.add_module(mod)
    ee.finalize_object()
    ee.run_static_constructors()

    func_ptr = ee.get_function_address("myfunc")
    cfunc = ctypes.CFUNCTYPE(None, ctypes.c_int64)(func_ptr)
    for i in range(20):
        cfunc(i)