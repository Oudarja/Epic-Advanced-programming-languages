from llvmlite import ir
import llvmlite.binding as llvm
import ctypes

llvm.initialize()
llvm.initialize_native_target()
llvm.initialize_native_asmprinter()

def print_wrapper(x):
    print("Got value", x)

printfn_type = ctypes.CFUNCTYPE(None, ctypes.c_int64)
printfn = printfn_type(print_wrapper)

llvm.add_symbol(
    "print",
    ctypes.cast(printfn, ctypes.c_void_p).value)

def create_execution_engine():
    target = llvm.Target.from_default_triple()
    target_machine = target.create_target_machine()
    backing_module = llvm.parse_assembly("")
    engine = llvm.create_mcjit_compiler(backing_module, target_machine)
    return engine

def create_module():
    i64_type = ir.IntType(bits=64)
    fn_type = ir.FunctionType(args=(i64_type,), return_type=ir.VoidType())

    module = ir.Module(name="test")
    print_func = ir.Function(module, ir.FunctionType(args=(i64_type,), return_type=ir.VoidType()), name="print")

    func = ir.Function(module, fn_type, name="myfunc")
    num = func.args[0]

    entry = func.append_basic_block(name="entry")
    loop = func.append_basic_block(name="loop")
    fin = func.append_basic_block(name="fin")

    entry_builder = ir.IRBuilder(entry)
    entry_builder.branch(loop)
    
    loop_builder = ir.IRBuilder(loop)
    phi = loop_builder.phi(i64_type, name="i")
    phi.add_incoming(num, entry)
    next_val = loop_builder.sub(phi, ir.Constant(i64_type, 1), name="i1")
    phi.add_incoming(next_val, loop)
    loop_builder.call(print_func, (phi,))
    cond = loop_builder.icmp_signed('==', next_val, ir.Constant(i64_type, 0), "cond")
    loop_builder.cbranch(cond, fin, loop)
    
    fin_builder = ir.IRBuilder(fin)
    fin_builder.ret_void()

    return module

module = create_module()
print("---- Compiled module ----")
print(module)
print("---- Compiled module ----")

with create_execution_engine() as ee:
    mod = llvm.parse_assembly(str(module))
    mod.verify()

    open('orig.bc', 'wb').write(mod.as_bitcode())

    pass_manager = llvm.PassManagerBuilder()
    pass_manager.opt_level = 3
    module_pass = llvm.ModulePassManager()
    pass_manager.populate(module_pass)
    module_pass.run(mod)

    open('opt.bc', 'wb').write(mod.as_bitcode())

    ee.add_module(mod)
    ee.finalize_object()
    ee.run_static_constructors()

    func_ptr = ee.get_function_address("myfunc")
    cfunc = ctypes.CFUNCTYPE(None, ctypes.c_int64)(func_ptr)
    cfunc(10)